import Logo from "../assets/edubelogo.png";

export const imageConstants = {
  logo: Logo,
};
