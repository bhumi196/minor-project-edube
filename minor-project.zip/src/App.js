import Routes from "./router";
import "./App.css";

function App() {
  return (
    <div className="App">
      <Routes />
    </div>
  );
}

export default App;
