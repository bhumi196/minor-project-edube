import { useState } from "react"
import {Button, Card, TextInput, FormContainer} from "../../components"
import { imageConstants } from "../../helpers/constants"

const Login = () => {
    const [email, setEmail] = useState("")
    const [pass, setPass] = useState("")

    return (
        <div className="container">
            <img src={imageConstants.logo} alt="logo" className="logo" />
            <Card>
                <FormContainer>

                    <TextInput type="text" value={email} placeholder="Username or email" onChange={(text) => { setEmail(text) }} />
                    <TextInput type="text" value={pass} placeholder="Password" onChange={(text) => { setPass(text) }} />
                    <Button type="button" value="Login" >Login</Button>

                </FormContainer>
            </Card>
        </div>
    )
}

export default Login