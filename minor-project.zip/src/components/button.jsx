import styled from "styled-components";

const Button = styled.button`
width: 100%;
height: 50px;
border-radius: 15px;
border: none;
color: white;
font-size: 24px;
margin: 5% 0;background: #FF512F;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #F09819, #FF512F);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #F09819, #FF512F); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */


`

export default Button;